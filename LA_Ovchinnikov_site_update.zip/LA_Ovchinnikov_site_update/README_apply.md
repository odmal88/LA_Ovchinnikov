# Обновление сайта Льва Авксентьевича Овчинникова

Пакет подготовлен для репозитория `odmal88/LA_Ovchinnikov`.

## Что входит

- `lib/data/works.ts` — заменяет временные placeholder-записи на 18 каталожных карточек Льва Авксентьевича Овчинникова.
- `public/works/lev/full/` — полные изображения работ.
- `public/works/lev/thumbs/` — миниатюры для каталога.
- `public/works/lev/details/` — обороты и архивные детали, размещаются на странице конкретной работы, не как отдельные карточки каталога.
- `components/works/work-card.tsx` — карточка каталога без жёсткой обрезки изображения.
- `components/works/image-zoom.tsx` — просмотр изображения с сохранением пропорций.
- `components/works/work-detail.tsx` — страница работы с описанием, надписями и архивными деталями.

## Как применить

Скопируйте содержимое этого пакета в корень репозитория `LA_Ovchinnikov` с заменой одноимённых файлов:

```bash
cp -R LA_Ovchinnikov_site_update/* /path/to/LA_Ovchinnikov/
cd /path/to/LA_Ovchinnikov
npm run lint
npm run build
```

После проверки:

```bash
git add lib/data/works.ts components/works/work-card.tsx components/works/image-zoom.tsx components/works/work-detail.tsx public/works/lev
git commit -m "Add Lev Ovchinnikov works catalog and images"
git push
```

## Логика размещения

Каждая работа получает отдельную страницу `/works/<slug>`. Оборотные стороны и архивные надписи не выводятся отдельными работами; они прикреплены как `imageDetails` к соответствующей карточке.

Если дата, техника, размер или атрибуция требуют проверки, это явно указано в карточке через статус `needs_review` или осторожную формулировку в полях материала / размера / описания.
